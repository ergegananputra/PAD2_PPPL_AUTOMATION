package pages.kajian.read.detail_kajian_original;

import org.openqa.selenium.WebDriver;

public class DetailKajianOriginalPage {
    WebDriver driver;
    DetailKajianOriginalObject detailKajianOriginalObject;

    public DetailKajianOriginalPage(WebDriver driver) {
        this.driver = driver;
        detailKajianOriginalObject = new DetailKajianOriginalObject(driver);
    }

    public void clickUserProfileLink() {
        driver.findElement(detailKajianOriginalObject.getUserProfileLink()).click();
    }

    public String getUserProfileImageSource() {
        return driver.findElement(detailKajianOriginalObject.getUserProfileImage()).getAttribute("src");
    }

    public String getUserName() {
        return driver.findElement(detailKajianOriginalObject.getUserName()).getText();
    }

    public String getKajianImageSource() {
        return driver.findElement(detailKajianOriginalObject.getKajianImage()).getAttribute("src");
    }

    public String getKajianTitle() {
        return driver.findElement(detailKajianOriginalObject.getKajianTitle()).getText();
    }

    public String getKajianSpeaker() {
        return driver.findElement(detailKajianOriginalObject.getKajianSpeaker()).getText();
    }

    public String getKajianDate() {
        return driver.findElement(detailKajianOriginalObject.getKajianDate()).getText();
    }

    public String getKajianLocation() {
        return driver.findElement(detailKajianOriginalObject.getKajianLocation()).getText();
    }

    public String getKajianDescription() {
        return driver.findElement(detailKajianOriginalObject.getKajianDescription()).getText();
    }

    public void clickDownloadKajianButton() {
        driver.findElement(detailKajianOriginalObject.getDownloadKajianButton()).click();
    }

    public void clickShareKajianButton() {
        driver.findElement(detailKajianOriginalObject.getShareKajianButton()).click();
    }

    public void clickUploadNewKajianButton() {
        driver.findElement(detailKajianOriginalObject.getUploadNewKajianButton()).click();
    }

    public String getNewKajianHeading() {
        return driver.findElement(detailKajianOriginalObject.getNewKajianHeading()).getText();
    }

    public String getNewKajianUserName() {
        return driver.findElement(detailKajianOriginalObject.getNewKajianUserName()).getText();
    }

    public String getNewKajianUserImageSource() {
        return driver.findElement(detailKajianOriginalObject.getNewKajianUserImage()).getAttribute("src");
    }

    public void clickNewKajianLink() {
        driver.findElement(detailKajianOriginalObject.getNewKajianLink()).click();
    }

    public void clickNewKajianArrowButton() {
        driver.findElement(detailKajianOriginalObject.getNewKajianArrowButton()).click();
    }
}
