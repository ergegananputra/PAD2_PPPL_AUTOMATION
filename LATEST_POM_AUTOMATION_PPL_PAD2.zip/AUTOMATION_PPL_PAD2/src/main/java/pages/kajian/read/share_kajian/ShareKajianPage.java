package pages.kajian.read.share_kajian;

import org.openqa.selenium.WebDriver;

public class ShareKajianPage {
    WebDriver driver;
    ShareKajianObject shareKajianObject;

    public ShareKajianPage(WebDriver driver) {
        this.driver = driver;
        shareKajianObject = new ShareKajianObject(driver);
    }

    public void clickShareKajianButton() {
        driver.findElement(shareKajianObject.getShareKajianButton()).click();
    }
}
