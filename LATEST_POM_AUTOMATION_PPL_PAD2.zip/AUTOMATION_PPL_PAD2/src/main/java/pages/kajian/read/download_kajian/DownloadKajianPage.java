package pages.kajian.read.download_kajian;

import org.openqa.selenium.WebDriver;

public class DownloadKajianPage {
    WebDriver driver;
    DownloadKajianObject downloadKajianObject;

    public DownloadKajianPage(WebDriver driver) {
        this.driver = driver;
        downloadKajianObject = new DownloadKajianObject(driver);
    }

    public void clickDownloadKajianButton() {
        driver.findElement(downloadKajianObject.getDownloadKajianButton()).click();
    }
}
