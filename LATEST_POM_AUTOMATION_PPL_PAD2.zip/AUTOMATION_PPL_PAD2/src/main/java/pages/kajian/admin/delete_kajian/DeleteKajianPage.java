package pages.kajian.admin.delete_kajian;

import org.openqa.selenium.WebDriver;
import pages.admin.dasboard.AdminDashboardPage;

public class DeleteKajianPage extends AdminDashboardPage {
    DeleteKajianObject deleteKajianObject;

    public DeleteKajianPage(WebDriver driver) {
        super(driver);
        deleteKajianObject = new DeleteKajianObject(driver);
    }

    public void clickDeleteKajianButton(int id) {
        driver.findElement(deleteKajianObject.getDeleteKajianButton(id)).click();
    }
}
