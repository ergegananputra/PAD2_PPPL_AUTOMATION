package pages.kajian.write.edit_deskripsi_kajian;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class EditDeskripsiKajianObject {
    WebDriver driver;
    public EditDeskripsiKajianObject(WebDriver driver) {
        this.driver = driver;
    }

    public By getEditButton() {
        return By.xpath("null");
    }
}
