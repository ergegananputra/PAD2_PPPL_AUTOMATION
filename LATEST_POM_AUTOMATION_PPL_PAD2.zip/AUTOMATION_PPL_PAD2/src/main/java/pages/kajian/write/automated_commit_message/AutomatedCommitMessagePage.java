package pages.kajian.write.automated_commit_message;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AutomatedCommitMessagePage {
    WebDriver driver;
    AutomatedCommitMessageObject automatedCommitMessageObject;

    public AutomatedCommitMessagePage(WebDriver driver) {
        this.driver = driver;
        automatedCommitMessageObject = new AutomatedCommitMessageObject();
    }

    public void inputCommitMessage(String message) {
        driver.findElement(automatedCommitMessageObject.getKontenTextarea()).sendKeys(message);
    }

    public void clickSubmit() {
        driver.findElement(automatedCommitMessageObject.getSubmitButton()).click();
    }

    public void clickCancel() {
        driver.findElement(automatedCommitMessageObject.getCancelButton()).click();
    }
}
