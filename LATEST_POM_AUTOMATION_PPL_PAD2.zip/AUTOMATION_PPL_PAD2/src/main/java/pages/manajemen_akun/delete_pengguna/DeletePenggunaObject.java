package pages.manajemen_akun.delete_pengguna;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DeletePenggunaObject {
    WebDriver driver;

    public DeletePenggunaObject(WebDriver driver) {
        this.driver = driver;
    }
    public By getHapusFotoProfilButton() {
        return By.xpath("//form[contains(@action, 'picture/delete')]//button");
    }
}
