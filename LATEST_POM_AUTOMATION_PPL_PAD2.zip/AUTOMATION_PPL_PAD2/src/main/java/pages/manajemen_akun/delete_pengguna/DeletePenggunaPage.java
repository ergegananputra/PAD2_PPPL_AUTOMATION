package pages.manajemen_akun.delete_pengguna;

import org.openqa.selenium.WebDriver;
import pages.admin.dasboard.AdminDashboardPage;

public class DeletePenggunaPage extends AdminDashboardPage {
    DeletePenggunaObject deletePenggunaObject;

    public DeletePenggunaPage(WebDriver driver) {
        super(driver);
        deletePenggunaObject = new DeletePenggunaObject(driver);
    }

    public void clickHapusFotoProfilButton() {
        driver.findElement(deletePenggunaObject.getHapusFotoProfilButton()).click();
    }

    public boolean isHapusFotoProfilButtonVisible() {
        return driver.findElement(deletePenggunaObject.getHapusFotoProfilButton()).isDisplayed();
    }
}
