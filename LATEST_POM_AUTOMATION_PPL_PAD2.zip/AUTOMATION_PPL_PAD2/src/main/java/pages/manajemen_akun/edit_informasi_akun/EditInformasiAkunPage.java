package pages.manajemen_akun.edit_informasi_akun;

import org.openqa.selenium.WebDriver;

public class EditInformasiAkunPage {
    WebDriver driver;
    EditInformasiAkunObject editInformasiAkunObject;

    public EditInformasiAkunPage(WebDriver driver) {
        this.driver = driver;
        editInformasiAkunObject = new EditInformasiAkunObject(driver);
    }

    public void clickBackButton() {
        driver.findElement(editInformasiAkunObject.getBackButton()).click();
    }

    public boolean isPageTitleVisible() {
        return driver.findElement(editInformasiAkunObject.getPageTitle()).isDisplayed();
    }

    public boolean isProfilePictureVisible() {
        return driver.findElement(editInformasiAkunObject.getProfilePicture()).isDisplayed();
    }

    public String getEmailPengguna() {
        return driver.findElement(editInformasiAkunObject.getEmailPengguna()).getText();
    }

    public void clickUbahFotoProfilButton() {
        driver.findElement(editInformasiAkunObject.getUbahFotoProfilButton()).click();
    }

    public void uploadFotoProfil(String filePath) {
        driver.findElement(editInformasiAkunObject.getFotoProfilInput()).sendKeys(filePath);
    }

    public void clickHapusFotoProfilButton() {
        driver.findElement(editInformasiAkunObject.getHapusFotoProfilButton()).click();
    }

    public void setUsername(String username) {
        driver.findElement(editInformasiAkunObject.getUsernameInput()).sendKeys(username);
    }

    public void setNamaLengkap(String namaLengkap) {
        driver.findElement(editInformasiAkunObject.getNamaLengkapInput()).sendKeys(namaLengkap);
    }

    public void setTempatLahir(String tempatLahir) {
        driver.findElement(editInformasiAkunObject.getTempatLahirInput()).sendKeys(tempatLahir);
    }

    public void setTanggalLahir(String tanggalLahir) {
        driver.findElement(editInformasiAkunObject.getTanggalLahirInput()).sendKeys(tanggalLahir);
    }

    public void setPekerjaan(String pekerjaan) {
        driver.findElement(editInformasiAkunObject.getPekerjaanInput()).sendKeys(pekerjaan);
    }

    public void setAlamat(String alamat) {
        driver.findElement(editInformasiAkunObject.getAlamatInput()).sendKeys(alamat);
    }

    public void selectJenisKelaminLakiLaki() {
        driver.findElement(editInformasiAkunObject.getJenisKelaminLakiLakiRadio()).click();
    }

    public void selectJenisKelaminPerempuan() {
        driver.findElement(editInformasiAkunObject.getJenisKelaminPerempuanRadio()).click();
    }

    public void selectStatusKeanggotaan(String status) {
        driver.findElement(editInformasiAkunObject.getStatusKeanggotaanSelect()).sendKeys(status);
    }

    public void setNomorKeanggotaan(String nomorKeanggotaan) {
        driver.findElement(editInformasiAkunObject.getNomorKeanggotaanInput()).sendKeys(nomorKeanggotaan);
    }

    public void setCabang(String cabang) {
        driver.findElement(editInformasiAkunObject.getCabangInput()).sendKeys(cabang);
    }

    public void setDaerah(String daerah) {
        driver.findElement(editInformasiAkunObject.getDaerahInput()).sendKeys(daerah);
    }

    public void setWilayah(String wilayah) {
        driver.findElement(editInformasiAkunObject.getWilayahInput()).sendKeys(wilayah);
    }

    public void uploadFotoKTA(String filePath) {
        driver.findElement(editInformasiAkunObject.getFotoKTAInput()).sendKeys(filePath);
    }

    public void clickSubmitButton() {
        driver.findElement(editInformasiAkunObject.getSubmitButton()).click();
    }
}
