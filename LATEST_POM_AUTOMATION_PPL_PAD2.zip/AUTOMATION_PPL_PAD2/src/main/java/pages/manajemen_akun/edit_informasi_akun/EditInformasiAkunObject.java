package pages.manajemen_akun.edit_informasi_akun;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class EditInformasiAkunObject {
    WebDriver driver;

    public EditInformasiAkunObject(WebDriver driver) {
        this.driver = driver;
    }

    public By getBackButton() {
        return By.cssSelector(".back-button");
    }

    public By getPageTitle() {
        return By.xpath("//h1[contains(text(), 'Ubah Informasi Akun')]");
    }

    public By getProfilePicture() {
        return By.cssSelector(".profile-picture");
    }

    public By getEmailPengguna() {
        return By.xpath("//p[strong]");
    }

    public By getUbahFotoProfilButton() {
        return By.cssSelector("label[for='foto_profile']");
    }

    public By getFotoProfilInput() {
        return By.id("foto_profile");
    }

    public By getHapusFotoProfilButton() {
        return By.xpath("//form[contains(@action, 'picture/delete')]//button");
    }

    public By getUsernameInput() {
        return By.id("val-nama");
    }

    public By getNamaLengkapInput() {
        return By.id("val-nama");
    }

    public By getTempatLahirInput() {
        return By.id("val-tempat-lahir");
    }

    public By getTanggalLahirInput() {
        return By.id("val-tanggal-lahir");
    }

    public By getPekerjaanInput() {
        return By.id("val-pekerjaan");
    }

    public By getAlamatInput() {
        return By.id("val-alamat");
    }

    public By getJenisKelaminLakiLakiRadio() {
        return By.id("val-jenis-kelamin-l");
    }

    public By getJenisKelaminPerempuanRadio() {
        return By.id("val-jenis-kelamin-p");
    }

    public By getStatusKeanggotaanSelect() {
        return By.id("val-status");
    }

    public By getNomorKeanggotaanInput() {
        return By.id("val-nomor-keanggotaan");
    }

    public By getCabangInput() {
        return By.id("val-cabang");
    }

    public By getDaerahInput() {
        return By.id("val-daerah");
    }

    public By getWilayahInput() {
        return By.id("val-wilayah");
    }

    public By getFotoKTAInput() {
        return By.id("foto-input");
    }

    public By getSubmitButton() {
        return By.cssSelector(".btn-green-submit");
    }
}
