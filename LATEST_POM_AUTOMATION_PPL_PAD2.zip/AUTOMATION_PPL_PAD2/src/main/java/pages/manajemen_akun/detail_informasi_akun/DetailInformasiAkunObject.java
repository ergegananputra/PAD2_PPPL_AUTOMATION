package pages.manajemen_akun.detail_informasi_akun;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DetailInformasiAkunObject {
    WebDriver driver;

    public DetailInformasiAkunObject(WebDriver driver) {
        this.driver = driver;
    }

    // Navbar links
    public By getBerandaLink() {
        return By.linkText("Beranda");
    }

    public By getKajianLink() {
        return By.linkText("Kajian");
    }

    public By getTentangKamiLink() {
        return By.linkText("Tentang Kami");
    }

    // Profile dropdown
    public By getProfileDropdown() {
        return By.id("dropdownMenu2");
    }

    public By getProfilPenggunaLink() {
        return By.xpath("//button[contains(text(), 'Profil Pengguna')]");
    }

    public By getInformasiAkunLink() {
        return By.xpath("//button[contains(text(), 'Informasi Akun')]");
    }

    public By getLogoutLink() {
        return By.xpath("//a[@onclick='event.preventDefault();this.closest(\"form\").submit();']");
    }

    // Account information
    public By getProfilePicture() {
        return By.cssSelector(".profile-picture");
    }

    public By getEmail() {
        return By.xpath("//p[strong]");
    }

    public By getUbahFotoProfilButton() {
        return By.cssSelector("label[for='foto_profile']");
    }

    public By getFotoProfilInput() {
        return By.id("foto_profile");
    }

    public By getHapusFotoProfilButton() {
        return By.xpath("//form[contains(@action, 'picture/delete')]//button");
    }

    public By getEditProfileButton() {
        return By.xpath("//button[contains(text(), 'Edit Profile')]");
    }

    public By getDataPribadiHeader() {
        return By.xpath("//h3[contains(text(), 'Data Pribadi')]");
    }

    public By getNamaLengkap() {
        return By.xpath("//div[contains(@class, 'row')][div/p[text()='Nama Lengkap']]/div[2]/p");
    }

    public By getTempatTanggalLahir() {
        return By.xpath("//div[contains(@class, 'row')][div/p[text()='Tempat, Tanggal Lahir']]/div[2]/p");
    }

    public By getProfesi() {
        return By.xpath("//div[contains(@class, 'row')][div/p[text()='Profesi']]/div[2]/p");
    }

    public By getJenisKelamin() {
        return By.xpath("//div[contains(@class, 'row')][div/p[text()='Jenis Kelamin']]/div[2]/p");
    }

    public By getAlamat() {
        return By.xpath("//div[contains(@class, 'row')][div/p[text()='Alamat']]/div[2]/p");
    }

    public By getDataKeanggotaanHeader() {
        return By.xpath("//h3[contains(text(), 'Data Keanggotaan')]");
    }

    public By getStatusKeanggotaan() {
        return By.xpath("//div[contains(@class, 'row')][div/p[text()='Status']]/div[2]/p");
    }
}