package pages.manajemen_akun.detail_informasi_akun;

import org.openqa.selenium.WebDriver;
import pages.admin.dasboard.AdminDashboardPage;

public class DetailInformasiAkunPage extends AdminDashboardPage {
    DetailInformasiAkunObject detailInformasiAkunObject;

    public DetailInformasiAkunPage(WebDriver driver) {
        super(driver);
        detailInformasiAkunObject = new DetailInformasiAkunObject(driver);
    }

    // Navbar links
    public void clickBerandaLink() {
        driver.findElement(detailInformasiAkunObject.getBerandaLink()).click();
    }

    public void clickKajianLink() {
        driver.findElement(detailInformasiAkunObject.getKajianLink()).click();
    }

    public void clickTentangKamiLink() {
        driver.findElement(detailInformasiAkunObject.getTentangKamiLink()).click();
    }

    // Profile dropdown
    public void clickProfileDropdown() {
        driver.findElement(detailInformasiAkunObject.getProfileDropdown()).click();
    }

    public void clickProfilPenggunaLink() {
        driver.findElement(detailInformasiAkunObject.getProfilPenggunaLink()).click();
    }

    public void clickInformasiAkunLink() {
        driver.findElement(detailInformasiAkunObject.getInformasiAkunLink()).click();
    }

    public void clickLogoutLink() {
        driver.findElement(detailInformasiAkunObject.getLogoutLink()).click();
    }

    // Account information
    public boolean isProfilePictureVisible() {
        return driver.findElement(detailInformasiAkunObject.getProfilePicture()).isDisplayed();
    }

    public String getEmail() {
        return driver.findElement(detailInformasiAkunObject.getEmail()).getText();
    }

    public void clickUbahFotoProfilButton() {
        driver.findElement(detailInformasiAkunObject.getUbahFotoProfilButton()).click();
    }

    public void uploadFotoProfil(String filePath) {
        driver.findElement(detailInformasiAkunObject.getFotoProfilInput()).sendKeys(filePath);
    }

    public void clickHapusFotoProfilButton() {
        driver.findElement(detailInformasiAkunObject.getHapusFotoProfilButton()).click();
    }

    public void clickEditProfileButton() {
        driver.findElement(detailInformasiAkunObject.getEditProfileButton()).click();
    }

    public boolean isDataPribadiHeaderVisible() {
        return driver.findElement(detailInformasiAkunObject.getDataPribadiHeader()).isDisplayed();
    }

    public String getNamaLengkap() {
        return driver.findElement(detailInformasiAkunObject.getNamaLengkap()).getText();
    }

    public String getTempatTanggalLahir() {
        return driver.findElement(detailInformasiAkunObject.getTempatTanggalLahir()).getText();
    }

    public String getProfesi() {
        return driver.findElement(detailInformasiAkunObject.getProfesi()).getText();
    }

    public String getJenisKelamin() {
        return driver.findElement(detailInformasiAkunObject.getJenisKelamin()).getText();
    }

    public String getAlamat() {
        return driver.findElement(detailInformasiAkunObject.getAlamat()).getText();
    }

    public boolean isDataKeanggotaanHeaderVisible() {
        return driver.findElement(detailInformasiAkunObject.getDataKeanggotaanHeader()).isDisplayed();
    }

    public String getStatusKeanggotaan() {
        return driver.findElement(detailInformasiAkunObject.getStatusKeanggotaan()).getText();
    }
}
