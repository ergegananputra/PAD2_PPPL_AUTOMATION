package pages.utilities.filter;

public class FilterObject {
}
