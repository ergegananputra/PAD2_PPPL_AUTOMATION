package pages.about;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AboutObject {
    WebDriver driver;

    public AboutObject(WebDriver driver) {
        this.driver = driver;
    }

    public By getLogo() {
        return By.xpath("//*[contains(@class, 'navbar-brand')]/img");
    }

    public By getBerandaLink() {
        return By.xpath("//a[contains(@href, '/beranda') and contains(text(), 'Beranda')]");
    }

    public By getKajianLink() {
        return By.xpath("//a[contains(@href, '/kajian') and contains(text(), 'Kajian')]");
    }

    public By getTentangKamiLink() {
        return By.xpath("//a[contains(@href, '/about') and contains(text(), 'Tentang Kami')]");
    }


    public By getUserProfileImage() {
        return By.xpath("//*[contains(@class, 'btn-login')]/img");
    }

    public By getProfilePenggunaButton() {
        return By.xpath("//button[contains(.//span, 'Profil Pengguna')]");
    }


    public By getInformasiAkunButton() {
        return By.xpath("//button[contains(.//span, 'Informasi Akun')]");
    }

    public By getLogoutLink() {
        return By.xpath("//a[contains(.//span, 'Log Out')]");
    }

    public By getSearchResult(String keyword) {
        return By.xpath("//div[contains(@class, 'kajian-item') and (contains(@data-title, '" + keyword + "') or contains(@data-pemateri, '" + keyword + "') or contains(@data-deskripsi, '" + keyword + "') or contains(@data-kategori, '" + keyword + "'))]");
    }
    public By getCreateKajianButton() {
        return By.xpath("//section[@id='search']//a[contains(text(), 'Unggah Kajian')]");
    }
    public By getLihatSemuaLink() {
        return By.xpath("//section[@id='kajian-muhammadiyah']//a[contains(text(), 'Lihat Semua')]");
    }
    public By getNextButtonImage() {
        return By.xpath("//section[@id='kajian-muhammadiyah']//img[@alt='Next Button']");
    }

    public By getCardTitleByIndex(int index) {
        return By.xpath("(//section[@id='kajian-muhammadiyah']//div[@class='card-kajian-title'])[" + index + "]");
    }

    public By getCardDescriptionByIndex(int index) {
        return By.xpath("(//section[@id='kajian-muhammadiyah']//p[@class='card-kajian-text'])[" + index + "]");
    }

    public By getLihatSelengkapnyaLinkByIndex(int index) {
        return By.xpath("(//section[@id='kajian-muhammadiyah']//a[@class='btn btn-view'])[" + index + "]");
    }

}
